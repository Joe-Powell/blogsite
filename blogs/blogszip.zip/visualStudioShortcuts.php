<?php include './headerForBlogs.php'; ?>
<link rel="stylesheet" href="../css/visualStudioShortcuts.css">




<h1>Visual Studio Shortcuts<span></h1>
<div class='containAll'>
    <p><span>Multiple Cursors</span> Alt + CLICK</p>
    <p><span>Duplicate Line</span> SHIFT + ALT + UP/DOWN</p>
    <p><span>Select Word</span> CTRL + D</p>
    <p><span>Select All Instances of a Word</span> CTRL + SHIFT + L</p>
    <p><span>Undo</span> ctrl/cmd + z </p>
    <p><span>Toggle Side Bar</span> CTRL + B</p>
    <p><span>Toggle Built-in Terminal</span> CTRL + `</p>
    <p><span>Open User Settings</span> CTRL +</p>
    <p><span>Quick Open a File</span> CTRL + P</p>
    <p><span>Tab Through Open Files</span> CTRL + Tab</p>
    <p><span>Move File to Split Windows</span> CTRL + \</p>
    <p><span>Close File</span> CTRL + W</p>
    <p><span>zoom in out</span> CTRL + or -</p>
    <p><span>Global Search Replace</span> CTRL + SHIFT + F</p>
    <p><span>Toggle Comment a Line</span> CTRL + /</p>
    <p><span>Rename Symbol</span> F2</p>
    <p><span>Jump to Function Definition</span> CTRL + CLICK</p>
    <p><span>Select all occurance of current selection</span> CTRL + SHIFT + L</p>
    <p><span>wrap in tags</span> highlight the line then hit CTRL + SHIFT + P, type in wrap, then use Emmet: wrap with abbreviation hit enter and then type tag and enter again</p>

</div>






<?php include 'footerForBlogs.php'; ?>