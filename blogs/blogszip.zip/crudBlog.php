<?php include './headerForBlogs.php'; ?>
<link rel="stylesheet" href="../css/crudBlog.css">

<div class="image"></div>

<div class="containBlog">
    <p>Register an Account, Log in, Leave a post if logged in, be able to 
        edit your post if it's the same user, Upload photos, and much more. This
        is a project I made while learning the basics of C.R.U.D which stands for
        Create, Read, Update, and Delete. This project is not so much about the 
        visual experience, but what it can do with the data entered into a database.
        The thing I like about Php is that it's very dynamic wihout having to install
        so many dependencies. Php is here to stay with it always staying up to date and making
        improvements. Below is a link to the project itself, go ahead and create an account
        and then log in. I also added a Profile page to this site when you click on home and
        also you can view the person that dropped the post by clicking on view profile which
        will show you a page with all of their posts below their profile information. Yes
        this site needs a lot more work but for now this will be fine and I will always make
        improvements as time goes by. You can also upload pictures in your post as well
        as upload a profile picture. When you first sign up there will be a default emoji 
        until you upload your first imgage as your profile image.

        </p>

    
    
    
    
        <a href='http://myblogs.live/loginSocialMediaPosts/' target='_blank'>Click here for site </a>
 
</div>   







<?php include 'footerForBlogs.php'; ?>