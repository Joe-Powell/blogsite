<?php include 'header.php'; ?>
<link rel="stylesheet" href="./css/webDev.css">


<div class="topImage"></div>


<div class="containBlogs">

  <div class="parent parent1">
    <h1>C.R.U.D. Application made with Php, social media site.</h1>
    <h2> </h2>
    <div class="overlay">
      <h4> This is a CRUD app I made using Php. You can register an account, <span>log in, leave a post, upload photos,</span> and more.
        <a href='./blogs/crudBlog.php'> Read more</a>
      </h4>

    </div>


  </div>


  <div class="parent parent2">
    <h1><i class="fab fa-react"></i> Redux for React.js </h1>
    <h2></h2>
    <div class="overlay">
      <h4>
      After learning React, I thought it was gonna be smooth sailing from here,
      but Redux was a whole new technology to learn. In this blog I will 
      talk about how I learned Redux and how it works.
        <a href='./blogs/reactAndRedux.php' target="_blank"> Read more</a>
      </h4>

    </div>


  </div>
  <div class="parent parent2">
    <h1><i class="fab fa-react"></i> Redux for react flow</h1>
    <h2></h2>
    <div class="overlay">
      <h4> This is a CRUD app I made using Php.<span> You can register an account, log in, leave a post, upload photos, and much more.</span>
        <a href='./blogs/crudBlog.php' target="_blank"> Read more</a>
      </h4>

    </div>


  </div>
  <div class="parent parent2">
    <h1><i class="fab fa-react"></i> Redux for react flow</h1>
    <h2></h2>
    <div class="overlay">
      <h4> This is a CRUD app I made using Php.<span> You can register an account, log in, leave a post, upload photos, and much more.</span>
        <a href='./blogs/crudBlog.php'> Read more</a>
      </h4>

    </div>


  </div>


















</div>















<?php include 'footer.php'; ?>