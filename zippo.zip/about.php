


<?php include 'header.php'; ?>
<link rel="stylesheet" href="./css/aboutStyle.css">





    <main>
        <h1>Joe Powell</h1>
        <div class="images">
            <img src="images/cableCurl.jpg" alt="weight machine" height='130px'>
            <img src="images/joe11.jpg" alt="weight machine" height='130px'>
            <img src="images/joe18.jpg" alt="weight machine" height='130px'>
        </div>
        <div class="intro">
            <p>Hello, thanks for visiting my page! This site my blog site
                where you can get information on a lot of different subjects
                such as health and fitness, Supplements, web development, and much more.

            </p>
        </div>
    </main>














    <?php include 'footer.php'; ?>